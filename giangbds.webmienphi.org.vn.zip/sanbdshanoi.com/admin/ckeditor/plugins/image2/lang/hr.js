/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'hr', {
	alt: 'Alternativni tekst',
	btnUpload: 'Pošalji na server',
	captioned: 'Titl slike',
	captionPlaceholder: 'Titl',
	infoTab: 'Info slike',
	lockRatio: 'Zaključaj odnos',
	menu: 'Svojstva slika',
	pathName: 'slika',
	pathNameCaption: 'titl',
	resetSize: 'Obriši veličinu',
	resizer: 'Odaberi i povuci za promjenu veličine',
	title: 'Svojstva slika',
	uploadTab: 'Pošalji',
	urlMissing: 'Nedostaje URL slike.',
	altMissing: 'Nedostaje alternativni tekst.'
} );
